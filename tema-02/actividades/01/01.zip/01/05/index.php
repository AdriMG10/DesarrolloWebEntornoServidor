<!--
    Nombre: Adrián Merino Gamaza
    Curso: 2ºDAW
    Actividad: 2.1.5
    Descripción: Declaración y uso de las variables
-->

<!--
    Ejercicio 5.

    Hacer un programa que muestre en pantalla información de PHP con la función phpinfo(). Muestre la información centrada horizontalmente en la pantalla.
-->

<!DOCTYPE html>
<html>

<head>
    <title>Actividad 5</title>
</head>

<body>
    <center>
        <h1>Información de PHP</h1>
        <?php
        phpinfo();
        ?>
    </center>
</body>

</html>

?>