<?php

/*
    Nombre: Adrián Merino Gamaza
    Curso: 2ºDAW
    Actividad: 2.1.3
    Descripción: Declaración y uso de las variables
*/

/*
    Ejercicio 3.

    Crear dos variables de tipo string y concatenar. Guardar resultado en nueva variable y mostrar resultado.
*/

$string1 = "Adri ";
$string2 = "Merino";

$concatenacion = $string1 . $string2;

echo $concatenacion;

?>