<?php

/*
Controlador: binario.php
Descripción: pasa el número decimal a binario a 
partir de los valores del formulario
*/

# Modelo
// Carga el modelo
include 'models/modelBinario.php';

# Vista
// Carga la vista con el resultado
include 'views/viewResultado.php'

?>