<?php

/*
Controlador: hexadecimal.php
Descripción: pasa el número decimal a hexadecimal a 
partir de los valores del formulario
*/

# Modelo
// Carga el modelo
include 'models/modelHexadecimal.php';

# Vista
// Carga la vista con el resultado
include 'views/viewResultado.php'

?>