<?php

/*
    Modelo: modelBinario.php
    Descripción: Calcula los valores del formulario a binario
*/

$valTipo = 'BINARIO';

$valDec = $_POST['valDec'];

$valRes = decbin($valDec);

?>