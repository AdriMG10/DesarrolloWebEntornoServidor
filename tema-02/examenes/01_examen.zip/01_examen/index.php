<?php

/*
    Controlador: index.php
    Descripción: Carga el  formulario de  datos  para  la conversión
*/

# Modelo
// No necesita

# Vista
include "views/viewIndex.php";

?>