<?php

/*
Controlador: octal.php
Descripción: pasa el número decimal a octal a 
partir de los valores del formulario
*/

# Modelo
// Carga el modelo
include 'models/modelOctal.php';

# Vista
// Carga la vista con el resultado
include 'views/viewResultado.php'

?>