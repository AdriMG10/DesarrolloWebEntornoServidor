<?php

/*
    Controlador: calcular.php
    Descripción: Realiza el cálculo de lanzamiento de proyectiles a partir de
    los valores del formulario y muestra los resultados en la vista correspondiente
*/

include "models/modelCalcular.php";

include "views/resultado.php";

?>