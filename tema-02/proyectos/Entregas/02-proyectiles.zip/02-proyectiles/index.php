<?php

/*
    Controlador: index.php
    Descripción: Carga el formulario de datos para el cálculo de proyectiles
*/

include "views/index.html";

?>